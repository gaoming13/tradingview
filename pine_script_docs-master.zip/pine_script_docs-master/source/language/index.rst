Language Fundamentals
=====================

.. toctree::
   :maxdepth: 3
   :name: appendixtoc
   
   Structure_of_the_script
   Comments
   Identifiers
   Lines_wrapping
   Type_system
   Literals
   Operators
   Functions_and_annotations
   Expressions_declarations_and_statements
   Declaring_functions
