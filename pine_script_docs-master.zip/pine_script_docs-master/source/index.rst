.. pine_script_docs documentation master file, created by
   sphinx-quickstart on Wed Feb 20 18:26:50 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. Helpful doc https://devguide.python.org/documenting/#restructuredtext-primer

Pine Script |version| documentation
***********************************

.. toctree::
   :maxdepth: 3
   :name: mastertoc
   
   Introduction
   Example_of_an_indicator_in_Pine
   language/index
   essential/index
   annotations/index
   infra/index
   Pine_Script_release_notes
   appendix/index
   Where_can_I_get_more_information
