Annotations overview
====================

.. toctree::
   :maxdepth: 3
   :name: appendixtoc
   
   study_annotation
   plot_annotation
   Script_inputs
   Price_levels_hline
   Filling_in_the_background_with_fill
   Barcoloring_a_series_with_barcolor
   Background_coloring_with_bgcolor
   Plotting_shapes_chars_and_arrows
   Custom_OHLC_bars_and_candles
   Alert_conditions
